let ponteY;
let ponteCampoAberta = false;
let ponteCidadeAberta = false;
let carrosCampo = [];
let carrosCidade = [];
let pontos = 0;
let tempoRestante = 60;
let timer;
let jogoAtivo = false;
let velocidadeMin = 1.5;
let velocidadeMax = 3.5;

let suprimentosBons = ["🍎", "🥦", "🍓", "🌽", "🥕", "🌱", "🍅"];
let suprimentosRuins = ["☢️", "💀", "☠️", "⚠️", "🧨", "⚛️"];

let cenaFinalAtiva = false;
let produtosEntregues = [];
let telaExplicativa = true;

function setup() {
  createCanvas(800, 600);
  ponteY = height / 2;
  textSize(48);
  textAlign(LEFT, CENTER);
  timer = millis();
}

function draw() {
  background(200, 220, 255);

  if (telaExplicativa) {
    drawTelaExplicativa();
  } else {
    if (jogoAtivo) {
      if (tempoRestante > 0) {
        jogar();
      } else {
        jogoAtivo = false;
        iniciarCenaFinal();
      }
    }

    if (!jogoAtivo && !cenaFinalAtiva) {
      drawMenu();
    }

    if (cenaFinalAtiva) {
      drawCenaFinal();
    }
  }
}

function drawTelaExplicativa() {
  fill(0);
  textSize(36);
  textAlign(CENTER, CENTER);
  text("Instruções do Jogo", width / 2, 60);

  textSize(22);
  textAlign(CENTER, TOP);
  let inicioY = 130;
  let espacamento = 30;

  text("Controle a ponte para permitir ou barrar veículos e produtos!", width / 2, inicioY);
  text("✔ Produtos bons passando pela ponte = +3 pontos", width / 2, inicioY + espacamento * 2);
  text("✘ Produtos ruins passando = -2 pontos", width / 2, inicioY + espacamento * 3);
  text("✔ Barrar produtos ruins = +2 pontos", width / 2, inicioY + espacamento * 4);
  text("✘ Barrar produtos bons = -1 ponto", width / 2, inicioY + espacamento * 5);
  text("✔ Carros passando pela ponte = +3 pontos", width / 2, inicioY + espacamento * 6);
  text("✘ Barrar carros = -2 pontos", width / 2, inicioY + espacamento * 7);
  text("→ Se sua pontuação for maior que 105, você ganha!", width / 2, inicioY + espacamento * 9);

  textSize(28);
  text("Clique para Começar", width / 2, inicioY + espacamento * 11);
}

function drawMenu() {
  fill(0);
  textSize(48);
  textAlign(CENTER, CENTER);
  text("Jogo da Ponte", width / 2, height / 2 - 50);
  textSize(24);
  text("Clique para Iniciar", width / 2, height / 2 + 50);
}

function jogar() {
  if (millis() - timer > 1000 && tempoRestante > 0) {
    tempoRestante--;
    timer = millis();
  }

  fill(34, 139, 34);
  rect(0, 0, width, height / 2);
  fill(150);
  rect(0, height / 2, width, height / 2);

  fill(139, 69, 19);
  rect(width / 2 - 50, 0, 100, height);

  if (ponteCampoAberta) {
    fill(0, 255, 0, 100);
    rect(width / 2 - 50, 0, 100, height / 2);
  }

  if (ponteCidadeAberta) {
    fill(0, 255, 0, 100);
    rect(width / 2 - 50, height / 2, 100, height / 2);
  }

  // Gera produtos
  if (frameCount % 60 === 0) {
    let velocidade = random(velocidadeMin, velocidadeMax);
    let suprimento = random() > 0.5 ?
      random(suprimentosBons) :
      random(suprimentosRuins);
    let ruim = suprimentosRuins.includes(suprimento);

    carrosCampo.push({
      x: 0,
      y: height / 4,
      speed: velocidade,
      pontuado: false,
      parado: false,
      suprimento,
      suprimentoRuim: ruim
    });
  }

  // Gera carros
  if (frameCount % 80 === 0) {
    let velocidade = -random(velocidadeMin, velocidadeMax);
    carrosCidade.push({
      x: width,
      y: (3 * height) / 4,
      speed: velocidade,
      pontuado: false,
      parado: false
    });
  }

  // Atualiza produtos
  for (let i = carrosCampo.length - 1; i >= 0; i--) {
    let c = carrosCampo[i];

    if (!ponteCampoAberta && c.x > width / 2 - 50 && c.x < width / 2 + 50) {
      if (c.suprimentoRuim) pontos += 2;
      else pontos -= 1;
      carrosCampo.splice(i, 1);
      continue;
    }

    if (ponteCampoAberta && !c.pontuado && c.x >= width / 2 - 50 && c.x <= width / 2 + 50) {
      if (!c.suprimentoRuim) pontos += 3;
      c.pontuado = true;
    }

    c.x += c.speed;

    if (c.x > width) {
      if (c.suprimentoRuim && !c.pontuado) pontos -= 2;
      carrosCampo.splice(i, 1);
      continue;
    }

    push();
    translate(c.x + 24, c.y);
    scale(-1, 1);
    text("🚛", 0, 0);
    pop();
    textSize(32);
    text(c.suprimento, c.x, c.y - 20);
  }

  // Atualiza carros
  for (let i = carrosCidade.length - 1; i >= 0; i--) {
    let c = carrosCidade[i];

    if (!ponteCidadeAberta && c.x > width / 2 - 50 && c.x < width / 2 + 50) {
      pontos -= 2;
      carrosCidade.splice(i, 1);
      continue;
    }

    if (ponteCidadeAberta && !c.pontuado && c.x <= width / 2 + 50 && c.x >= width / 2 - 50) {
      pontos += 3;
      c.pontuado = true;
    }

    c.x += c.speed;

    if (c.x < 0) {
      carrosCidade.splice(i, 1);
      continue;
    }

    text("🚙", c.x, c.y);
  }

  fill(0);
  textSize(28);
  textAlign(CENTER);
  text("⏱ Tempo: " + tempoRestante + "s", width / 2, 30);
  text("⭐ Pontuação: " + pontos, width / 2, 70);
}

function mousePressed() {
  if (telaExplicativa) {
    telaExplicativa = false;
  } else {
    if (!jogoAtivo) {
      jogoAtivo = true;
      cenaFinalAtiva = false;
      pontos = 0;
      tempoRestante = 60;
      carrosCampo = [];
      carrosCidade = [];
      ponteCampoAberta = false;
      ponteCidadeAberta = false;
      timer = millis();
    } else {
      if (mouseY < height / 2) {
        ponteCampoAberta = !ponteCampoAberta;
        ponteCidadeAberta = false;
      } else {
        ponteCidadeAberta = !ponteCidadeAberta;
        ponteCampoAberta = false;
      }
    }
  }
}

function iniciarCenaFinal() {
  cenaFinalAtiva = true;
  produtosEntregues = [];
  if (pontos > 105) {
    for (let i = 0; i < 5; i++) {
      produtosEntregues.push({
        emoji: random(suprimentosBons),
        x: random(width),
        y: height,
        speed: random(1, 2)
      });
    }
  }
}

function drawCenaFinal() {
  background(255);

  if (pontos > 105) {
    fill(0, 150, 0);
    textAlign(CENTER);
    textSize(48);
    text("Parabéns! Você ganhou!", width / 2, 60);

    for (let p of produtosEntregues) {
      textSize(32);
      text(p.emoji, p.x, p.y);
      p.y -= p.speed;
      if (p.y < 0) {
        p.y = height;
        p.x = random(width);
      }
    }
  } else {
    fill(150, 0, 0);
    textAlign(CENTER);
    textSize(48);
    text("Você perdeu!", width / 2, height / 2 - 30);
    textSize(32);
    text("Pontuação final: " + pontos, width / 2, height / 2 + 20);
    textSize(24);
    text("Clique para tentar novamente", width / 2, height / 2 + 70);
  }
}
